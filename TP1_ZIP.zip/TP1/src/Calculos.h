/*
 * calculos.h
 *
 *  Created on: 9 abr. 2021
 *      Author: Compumar
 */

#ifndef CALCULOS_H_
#define CALCULOS_H_
#include <stdio.h>

int RealizarOperaciones(int);
int Sumar(int, int, int);
int Restar(int, int, int);
float Dividir(float, int, int);
int Multiplicar(int, int, int);
int FactorialPrimerOperando(int, int);
int FactorialSegundoOperando(int, int);
void MostrarEcuaciones(int, int, int, int, int, float, int, int);







#endif /* CALCULOS_H_ */
